#Algorithms & Data Structure Project
**Topic：Social Network**  
**Author:Yanfang Guo**   
**Contact: Yanfang.Guo@vub.be**

##External Java Libraries
I used these  third party Java Libraries in the main function, when I try to create some users, some companys, some ads...etc, read some variables from some .txt file, then use these libraries.

No other third library used except these below. 

* java.io.BufferedReader;  
* java.io.FileNotFoundException;  
* java.io.FileReader;  
* java.io.IOException;

##Directories
* datastru: contains all basic data structures I implemented such as linkedlist, queue, graph.
* socialNetwork: contains all code related this socialNetwork, such as Profile, Message.
* txt : contain some .txt file used in initialization a network in main function.




